const grid = document.getElementById("art-grid");
const count = document.getElementById("art-count");
const search = document.getElementById("art-search");
const dialog = document.getElementById("lightbox");
const viewerImage = document.getElementById("lightbox-image");
const viewerCaption = document.getElementById("lightbox-caption");
let artworks = [];
let visibleArtworks = [];
let currentIndex = 0;

async function loadArtworks() {
  try {
    const response = await fetch("assets/artworks.json");
    if (!response.ok) throw new Error("Gallery manifest could not be loaded.");
    artworks = await response.json();
    renderGallery(artworks);
  } catch (error) {
    count.textContent = "Could not load the gallery. Please run this site using a local web server.";
    console.error(error);
  }
}

function renderGallery(items) {
  visibleArtworks = items;
  grid.innerHTML = "";
  count.textContent = `${items.length} ${items.length === 1 ? "artwork" : "artworks"}`;
  items.forEach((art, index) => {
    const button = document.createElement("button");
    button.className = "art-card";
    button.type = "button";
    button.setAttribute("aria-label", `View ${art.title}`);
    const image = document.createElement("img");
    image.src = art.src;
    image.alt = art.title;
    image.loading = "lazy";
    const label = document.createElement("span");
    label.textContent = art.title;
    button.append(image, label);
    button.addEventListener("click", () => openViewer(index));
    grid.appendChild(button);
  });
}

function openViewer(index) {
  currentIndex = index;
  const art = visibleArtworks[currentIndex];
  viewerImage.src = art.src;
  viewerImage.alt = art.title;
  viewerCaption.textContent = art.title;
  dialog.showModal();
}
function moveViewer(direction) {
  if (!visibleArtworks.length) return;
  currentIndex = (currentIndex + direction + visibleArtworks.length) % visibleArtworks.length;
  openViewer(currentIndex);
}
document.querySelector(".lightbox-close").addEventListener("click", () => dialog.close());
document.querySelector(".lightbox-prev").addEventListener("click", () => moveViewer(-1));
document.querySelector(".lightbox-next").addEventListener("click", () => moveViewer(1));
dialog.addEventListener("click", event => { if (event.target === dialog) dialog.close(); });
document.addEventListener("keydown", event => {
  if (!dialog.open) return;
  if (event.key === "ArrowLeft") moveViewer(-1);
  if (event.key === "ArrowRight") moveViewer(1);
});
search.addEventListener("input", () => {
  const query = search.value.trim().toLowerCase();
  renderGallery(artworks.filter(art => art.title.toLowerCase().includes(query)));
});

const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuButton.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => nav.classList.remove("open")));

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
document.getElementById("year").textContent = new Date().getFullYear();
loadArtworks();
