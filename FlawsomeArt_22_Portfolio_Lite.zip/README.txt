# FlawsomeArt_22 Portfolio

A responsive static art portfolio built with HTML, CSS and JavaScript.

## Run locally
Because the gallery loads `assets/artworks.json` with `fetch`, run the folder through a local web server instead of opening `index.html` directly.

If Python is installed:
1. Open a terminal in this folder.
2. Run `python -m http.server 8000`
3. Visit `http://localhost:8000`

## Publish
Upload the contents of this folder to GitHub Pages, Netlify or another static hosting provider. Keep the `assets` folder alongside `index.html`.

## Gallery
The supplied PDF contains 94 pages with 94 distinct embedded images. All 94 are included in `assets/artworks/`. Artwork thumbnails use a crop-to-fill presentation; opening an artwork shows the full image without cropping.

## Personal details
Email: flawsomeart2205@gmail.com
Instagram: https://www.instagram.com/flawsomeart_22/
